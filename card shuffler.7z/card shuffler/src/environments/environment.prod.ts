export const environment = {
  production: true,
  domain: '',
};
